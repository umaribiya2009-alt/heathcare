const Appointment = require('../models/Appointment');
const Report = require('../models/Report');
const Payment = require('../models/Payment');

// Returns a consolidated view of a patient's booking -> payment -> report journey
exports.getJourney = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.appointmentId)
      .populate('test')
      .populate('patient', 'name email');

    if (!appointment) return res.status(404).json({ message: 'Appointment not found' });
    if (
      req.user.role === 'patient' &&
      appointment.patient._id.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    const payment = await Payment.findOne({ appointment: appointment._id }).sort({ createdAt: -1 });
    const report = await Report.findOne({ appointment: appointment._id });

    const steps = [
      { key: 'booked', label: 'Test Booked' },
      { key: 'confirmed', label: 'Payment Confirmed' },
      { key: 'sample_collected', label: 'Sample Collected' },
      { key: 'processing', label: 'Lab Processing' },
      { key: 'report_ready', label: 'Report Ready' },
      { key: 'completed', label: 'Report Delivered' },
    ];
    const order = steps.map((s) => s.key);
    const currentIndex = order.indexOf(appointment.status);

    const journey = steps.map((s, idx) => ({
      ...s,
      done: appointment.status === 'cancelled' ? false : idx <= currentIndex,
      current: s.key === appointment.status,
    }));

    res.json({
      appointment,
      payment,
      report,
      journey,
      cancelled: appointment.status === 'cancelled',
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Patient dashboard summary: counts across all their appointments
exports.getDashboardSummary = async (req, res) => {
  try {
    const appointments = await Appointment.find({ patient: req.user._id });
    const summary = {
      total: appointments.length,
      upcoming: appointments.filter((a) => ['booked', 'confirmed'].includes(a.status)).length,
      inProgress: appointments.filter((a) => ['sample_collected', 'processing'].includes(a.status))
        .length,
      reportsReady: appointments.filter((a) => a.status === 'report_ready').length,
      completed: appointments.filter((a) => a.status === 'completed').length,
      cancelled: appointments.filter((a) => a.status === 'cancelled').length,
    };
    res.json({ summary });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
