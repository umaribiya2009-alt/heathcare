const { v4: uuidv4 } = require('uuid');
const Payment = require('../models/Payment');
const Appointment = require('../models/Appointment');
const Test = require('../models/Test');

/**
 * This is a MOCK payment flow suitable for development/demo.
 * To go live, swap the "processPayment" logic with a real gateway
 * (Razorpay/Stripe order-create + webhook verification) while
 * keeping the same request/response contract for the frontend.
 */

exports.initiatePayment = async (req, res) => {
  try {
    const { appointmentId, method } = req.body;
    const appointment = await Appointment.findById(appointmentId).populate('test');
    if (!appointment) return res.status(404).json({ message: 'Appointment not found' });
    if (appointment.patient.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    const payment = await Payment.create({
      appointment: appointmentId,
      patient: req.user._id,
      amount: appointment.test.price,
      method: method || 'card',
      status: 'pending',
      transactionId: `TXN-${uuidv4().slice(0, 8).toUpperCase()}`,
    });

    res.status(201).json({ payment });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Simulates gateway confirmation callback
exports.confirmPayment = async (req, res) => {
  try {
    const payment = await Payment.findById(req.params.id);
    if (!payment) return res.status(404).json({ message: 'Payment not found' });
    if (payment.patient.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    // Mock: 100% success in dev. Replace with real gateway verification.
    payment.status = 'success';
    await payment.save();

    const appointment = await Appointment.findById(payment.appointment);
    appointment.status = 'confirmed';
    appointment.timeline.push({ status: 'confirmed', note: 'Payment received, appointment confirmed' });
    await appointment.save();

    res.json({ payment, appointment });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getMyPayments = async (req, res) => {
  try {
    const payments = await Payment.find({ patient: req.user._id })
      .populate({ path: 'appointment', populate: 'test' })
      .sort({ createdAt: -1 });
    res.json({ payments });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
