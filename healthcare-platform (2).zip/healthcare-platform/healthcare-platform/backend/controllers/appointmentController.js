const Appointment = require('../models/Appointment');
const Test = require('../models/Test');

// Patient books a diagnostic test appointment
exports.createAppointment = async (req, res) => {
  try {
    const { testId, bookingType, scheduledDate, scheduledSlot, address, notes } = req.body;
    if (!testId || !scheduledDate || !scheduledSlot) {
      return res.status(400).json({ message: 'testId, scheduledDate and scheduledSlot are required' });
    }
    const test = await Test.findById(testId);
    if (!test || !test.isActive) return res.status(404).json({ message: 'Test not found' });

    if (bookingType === 'home_collection' && !address) {
      return res.status(400).json({ message: 'Address is required for home collection' });
    }

    const appointment = await Appointment.create({
      patient: req.user._id,
      test: testId,
      bookingType: bookingType || 'lab_visit',
      scheduledDate,
      scheduledSlot,
      address,
      notes,
      timeline: [{ status: 'booked', note: 'Appointment booked by patient' }],
    });

    const populated = await appointment.populate('test');
    res.status(201).json({ appointment: populated });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Patient: view own bookings
exports.getMyAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find({ patient: req.user._id })
      .populate('test')
      .sort({ createdAt: -1 });
    res.json({ appointments });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Admin/lab_staff: view all bookings (optionally filter by status)
exports.getAllAppointments = async (req, res) => {
  try {
    const { status } = req.query;
    const filter = {};
    if (status) filter.status = status;
    const appointments = await Appointment.find(filter)
      .populate('test')
      .populate('patient', 'name email phone')
      .sort({ createdAt: -1 });
    res.json({ appointments });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getAppointmentById = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id)
      .populate('test')
      .populate('patient', 'name email phone');
    if (!appointment) return res.status(404).json({ message: 'Appointment not found' });

    // patients may only view their own appointment
    if (
      req.user.role === 'patient' &&
      appointment.patient._id.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    res.json({ appointment });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Patient: cancel own booking (only if not yet processing)
exports.cancelAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id);
    if (!appointment) return res.status(404).json({ message: 'Appointment not found' });
    if (appointment.patient.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    if (['sample_collected', 'processing', 'report_ready', 'completed'].includes(appointment.status)) {
      return res.status(400).json({ message: 'Cannot cancel at this stage' });
    }
    appointment.status = 'cancelled';
    appointment.timeline.push({ status: 'cancelled', note: 'Cancelled by patient' });
    await appointment.save();
    res.json({ appointment });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Admin/lab_staff: update status as the test progresses (drives the journey tracker)
exports.updateAppointmentStatus = async (req, res) => {
  try {
    const { status, note } = req.body;
    const validStatuses = [
      'booked',
      'confirmed',
      'sample_collected',
      'processing',
      'report_ready',
      'completed',
      'cancelled',
    ];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }
    const appointment = await Appointment.findById(req.params.id);
    if (!appointment) return res.status(404).json({ message: 'Appointment not found' });

    appointment.status = status;
    appointment.timeline.push({ status, note: note || `Status updated to ${status}` });
    await appointment.save();

    res.json({ appointment });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
