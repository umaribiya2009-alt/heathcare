const Report = require('../models/Report');
const Appointment = require('../models/Appointment');

// Admin/lab_staff: upload a report for a completed test
exports.uploadReport = async (req, res) => {
  try {
    const { appointmentId, summary } = req.body;
    if (!req.file) return res.status(400).json({ message: 'Report file is required' });

    const appointment = await Appointment.findById(appointmentId);
    if (!appointment) return res.status(404).json({ message: 'Appointment not found' });

    const report = await Report.create({
      appointment: appointmentId,
      patient: appointment.patient,
      fileName: req.file.originalname,
      fileUrl: `/uploads/reports/${req.file.filename}`,
      fileType: req.file.mimetype,
      summary,
      uploadedBy: req.user._id,
    });

    appointment.status = 'report_ready';
    appointment.timeline.push({ status: 'report_ready', note: 'Report uploaded' });
    await appointment.save();

    res.status(201).json({ report });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Patient: view all their reports
exports.getMyReports = async (req, res) => {
  try {
    const reports = await Report.find({ patient: req.user._id })
      .populate({ path: 'appointment', populate: { path: 'test' } })
      .sort({ createdAt: -1 });
    res.json({ reports });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Patient: fetch single report and mark as viewed (also marks journey completed)
exports.getReportById = async (req, res) => {
  try {
    const report = await Report.findById(req.params.id).populate({
      path: 'appointment',
      populate: { path: 'test' },
    });
    if (!report) return res.status(404).json({ message: 'Report not found' });
    if (
      req.user.role === 'patient' &&
      report.patient.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    if (!report.viewedByPatient && req.user.role === 'patient') {
      report.viewedByPatient = true;
      await report.save();

      const appointment = await Appointment.findById(report.appointment._id);
      if (appointment && appointment.status !== 'completed') {
        appointment.status = 'completed';
        appointment.timeline.push({ status: 'completed', note: 'Report viewed by patient' });
        await appointment.save();
      }
    }

    res.json({ report });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
