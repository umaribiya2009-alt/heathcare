const express = require('express');
const router = express.Router();
const { getJourney, getDashboardSummary } = require('../controllers/journeyController');
const { protect } = require('../middleware/auth');

router.get('/summary', protect, getDashboardSummary);
router.get('/:appointmentId', protect, getJourney);

module.exports = router;
