const express = require('express');
const multer = require('multer');
const path = require('path');
const router = express.Router();
const { uploadReport, getMyReports, getReportById } = require('../controllers/reportController');
const { protect, authorize } = require('../middleware/auth');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', 'uploads', 'reports')),
  filename: (req, file, cb) => {
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${unique}${path.extname(file.originalname)}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['application/pdf', 'image/png', 'image/jpeg'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only PDF, PNG or JPEG files are allowed'));
  },
});

router.post('/', protect, authorize('admin', 'lab_staff'), upload.single('report'), uploadReport);
router.get('/mine', protect, getMyReports);
router.get('/:id', protect, getReportById);

module.exports = router;
