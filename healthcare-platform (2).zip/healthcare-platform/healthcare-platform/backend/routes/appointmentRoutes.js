const express = require('express');
const router = express.Router();
const {
  createAppointment,
  getMyAppointments,
  getAllAppointments,
  getAppointmentById,
  cancelAppointment,
  updateAppointmentStatus,
} = require('../controllers/appointmentController');
const { protect, authorize } = require('../middleware/auth');

router.post('/', protect, createAppointment);
router.get('/mine', protect, getMyAppointments);
router.get('/', protect, authorize('admin', 'lab_staff'), getAllAppointments);
router.get('/:id', protect, getAppointmentById);
router.patch('/:id/cancel', protect, cancelAppointment);
router.patch('/:id/status', protect, authorize('admin', 'lab_staff'), updateAppointmentStatus);

module.exports = router;
