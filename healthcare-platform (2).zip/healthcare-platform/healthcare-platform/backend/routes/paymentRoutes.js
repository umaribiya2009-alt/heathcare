const express = require('express');
const router = express.Router();
const { initiatePayment, confirmPayment, getMyPayments } = require('../controllers/paymentController');
const { protect } = require('../middleware/auth');

router.post('/', protect, initiatePayment);
router.post('/:id/confirm', protect, confirmPayment);
router.get('/mine', protect, getMyPayments);

module.exports = router;
