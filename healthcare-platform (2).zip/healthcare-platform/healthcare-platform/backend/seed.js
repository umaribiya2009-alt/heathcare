require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const Test = require('./models/Test');
const User = require('./models/User');

const sampleTests = [
  { name: 'Complete Blood Count (CBC)', category: 'Blood Test', price: 300, sampleType: 'Blood', fastingRequired: false, reportTimeHours: 6 },
  { name: 'Lipid Profile', category: 'Blood Test', price: 600, sampleType: 'Blood', fastingRequired: true, reportTimeHours: 12 },
  { name: 'Thyroid Profile (T3, T4, TSH)', category: 'Blood Test', price: 500, sampleType: 'Blood', fastingRequired: false, reportTimeHours: 24 },
  { name: 'HbA1c (Diabetes)', category: 'Blood Test', price: 450, sampleType: 'Blood', fastingRequired: false, reportTimeHours: 12 },
  { name: 'Chest X-Ray', category: 'Imaging', price: 400, sampleType: 'N/A', fastingRequired: false, reportTimeHours: 4, homeCollectionAvailable: false },
  { name: 'Abdominal Ultrasound', category: 'Imaging', price: 1200, sampleType: 'N/A', fastingRequired: true, reportTimeHours: 6, homeCollectionAvailable: false },
  { name: 'ECG (Electrocardiogram)', category: 'Cardiology', price: 350, sampleType: 'N/A', fastingRequired: false, reportTimeHours: 2, homeCollectionAvailable: false },
  { name: 'COVID-19 RT-PCR', category: 'Infectious Disease', price: 700, sampleType: 'Swab', fastingRequired: false, reportTimeHours: 24 },
  { name: 'Urine Routine & Microscopy', category: 'Urine Test', price: 200, sampleType: 'Urine', fastingRequired: false, reportTimeHours: 6 },
  { name: 'Vitamin D Test', category: 'Blood Test', price: 800, sampleType: 'Blood', fastingRequired: false, reportTimeHours: 24 },
];

const run = async () => {
  await connectDB();

  await Test.deleteMany({});
  await Test.insertMany(sampleTests);
  console.log(`Seeded ${sampleTests.length} diagnostic tests.`);

  const adminEmail = 'admin@healthcare.com';
  const existingAdmin = await User.findOne({ email: adminEmail });
  if (!existingAdmin) {
    await User.create({
      name: 'Platform Admin',
      email: adminEmail,
      password: 'Admin@123',
      role: 'admin',
    });
    console.log(`Created admin user -> email: ${adminEmail} / password: Admin@123`);
  } else {
    console.log('Admin user already exists, skipping.');
  }

  const labEmail = 'lab@healthcare.com';
  const existingLab = await User.findOne({ email: labEmail });
  if (!existingLab) {
    await User.create({
      name: 'Lab Staff',
      email: labEmail,
      password: 'Lab@1234',
      role: 'lab_staff',
    });
    console.log(`Created lab_staff user -> email: ${labEmail} / password: Lab@1234`);
  }

  await mongoose.connection.close();
  process.exit(0);
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
