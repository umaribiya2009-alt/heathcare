const mongoose = require('mongoose');

const appointmentSchema = new mongoose.Schema(
  {
    patient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    test: { type: mongoose.Schema.Types.ObjectId, ref: 'Test', required: true },
    bookingType: { type: String, enum: ['home_collection', 'lab_visit'], default: 'lab_visit' },
    scheduledDate: { type: Date, required: true },
    scheduledSlot: { type: String, required: true }, // e.g. "09:00 AM - 10:00 AM"
    address: { type: String }, // required if home_collection
    status: {
      type: String,
      enum: [
        'booked',          // patient booked, awaiting payment/confirmation
        'confirmed',       // payment done, confirmed
        'sample_collected', // for lab tests
        'processing',      // lab processing sample / test in progress
        'report_ready',    // report uploaded
        'completed',       // full journey done, report delivered/viewed
        'cancelled',
      ],
      default: 'booked',
    },
    notes: { type: String },
    timeline: [
      {
        status: { type: String, required: true },
        note: { type: String },
        timestamp: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Appointment', appointmentSchema);
