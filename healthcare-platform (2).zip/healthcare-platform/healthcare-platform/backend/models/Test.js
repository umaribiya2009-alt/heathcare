const mongoose = require('mongoose');

const testSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    category: { type: String, required: true, trim: true }, // e.g. Blood Test, Imaging, Cardiology
    description: { type: String },
    price: { type: Number, required: true },
    sampleType: { type: String, default: 'N/A' }, // Blood, Urine, Swab, N/A (for imaging)
    fastingRequired: { type: Boolean, default: false },
    reportTimeHours: { type: Number, default: 24 }, // typical turnaround time
    homeCollectionAvailable: { type: Boolean, default: true },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Test', testSchema);
