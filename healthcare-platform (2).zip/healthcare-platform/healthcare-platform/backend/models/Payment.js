const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema(
  {
    appointment: { type: mongoose.Schema.Types.ObjectId, ref: 'Appointment', required: true },
    patient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    amount: { type: Number, required: true },
    currency: { type: String, default: 'INR' },
    method: { type: String, enum: ['card', 'upi', 'netbanking', 'wallet', 'cash'], default: 'card' },
    status: { type: String, enum: ['pending', 'success', 'failed', 'refunded'], default: 'pending' },
    transactionId: { type: String },
    gateway: { type: String, default: 'mock' }, // swap with 'razorpay' / 'stripe' in production
  },
  { timestamps: true }
);

module.exports = mongoose.model('Payment', paymentSchema);
