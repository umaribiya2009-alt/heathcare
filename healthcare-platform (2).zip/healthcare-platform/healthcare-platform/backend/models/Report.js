const mongoose = require('mongoose');

const reportSchema = new mongoose.Schema(
  {
    appointment: { type: mongoose.Schema.Types.ObjectId, ref: 'Appointment', required: true },
    patient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true }, // path/URL to stored file (PDF etc.)
    fileType: { type: String, default: 'application/pdf' },
    summary: { type: String }, // optional short summary / key findings
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // lab_staff/admin
    viewedByPatient: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Report', reportSchema);
