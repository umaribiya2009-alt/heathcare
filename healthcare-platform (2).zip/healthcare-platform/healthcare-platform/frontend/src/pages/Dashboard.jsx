import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext.jsx';

export default function Dashboard() {
  const { user } = useAuth();
  const [summary, setSummary] = useState(null);
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [summaryRes, apptRes] = await Promise.all([
          api.get('/journey/summary'),
          api.get('/appointments/mine'),
        ]);
        setSummary(summaryRes.data.summary);
        setRecent(apptRes.data.appointments.slice(0, 5));
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const cards = summary
    ? [
        { label: 'Total Bookings', value: summary.total, color: 'bg-slate-100 text-slate-800' },
        { label: 'Upcoming', value: summary.upcoming, color: 'bg-blue-50 text-blue-700' },
        { label: 'In Progress', value: summary.inProgress, color: 'bg-amber-50 text-amber-700' },
        { label: 'Reports Ready', value: summary.reportsReady, color: 'bg-emerald-50 text-emerald-700' },
        { label: 'Completed', value: summary.completed, color: 'bg-violet-50 text-violet-700' },
      ]
    : [];

  const statusBadge = (status) => {
    const map = {
      booked: 'bg-slate-100 text-slate-700',
      confirmed: 'bg-blue-100 text-blue-700',
      sample_collected: 'bg-amber-100 text-amber-700',
      processing: 'bg-amber-100 text-amber-700',
      report_ready: 'bg-emerald-100 text-emerald-700',
      completed: 'bg-violet-100 text-violet-700',
      cancelled: 'bg-red-100 text-red-700',
    };
    return map[status] || 'bg-slate-100 text-slate-700';
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-900">Hi {user?.name?.split(' ')[0]}, welcome back 👋</h1>
      <p className="text-slate-500 mt-1">Here's a quick look at your healthcare journey.</p>

      {loading ? (
        <p className="mt-8 text-slate-400">Loading dashboard...</p>
      ) : (
        <>
          <div className="mt-8 grid grid-cols-2 md:grid-cols-5 gap-4">
            {cards.map((c) => (
              <div key={c.label} className={`rounded-2xl p-5 ${c.color}`}>
                <p className="text-3xl font-bold">{c.value}</p>
                <p className="text-sm mt-1">{c.label}</p>
              </div>
            ))}
          </div>

          <div className="mt-10 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-slate-900">Recent bookings</h2>
            <Link to="/my-bookings" className="text-sm text-brand-600 font-medium">
              View all →
            </Link>
          </div>

          <div className="mt-4 bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100">
            {recent.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                No bookings yet.{' '}
                <Link to="/book-test" className="text-brand-600 font-medium">
                  Book your first test
                </Link>
              </div>
            ) : (
              recent.map((a) => (
                <Link
                  to={`/journey/${a._id}`}
                  key={a._id}
                  className="flex items-center justify-between p-4 hover:bg-slate-50"
                >
                  <div>
                    <p className="font-medium text-slate-800">{a.test?.name}</p>
                    <p className="text-sm text-slate-500">
                      {new Date(a.scheduledDate).toLocaleDateString()} • {a.scheduledSlot}
                    </p>
                  </div>
                  <span className={`text-xs font-semibold px-3 py-1 rounded-full ${statusBadge(a.status)}`}>
                    {a.status.replace('_', ' ')}
                  </span>
                </Link>
              ))
            )}
          </div>

          <div className="mt-8 flex gap-4">
            <Link
              to="/book-test"
              className="px-5 py-2.5 rounded-lg bg-brand-500 text-white font-semibold hover:bg-brand-600"
            >
              + Book a New Test
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
