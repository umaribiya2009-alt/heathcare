import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api/axios';

export default function Journey() {
  const { appointmentId } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get(`/journey/${appointmentId}`)
      .then((res) => setData(res.data))
      .finally(() => setLoading(false));
  }, [appointmentId]);

  if (loading) return <p className="text-center py-20 text-slate-400">Loading journey...</p>;
  if (!data) return <p className="text-center py-20 text-red-500">Could not load journey.</p>;

  const { appointment, payment, report, journey, cancelled } = data;

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-900">Journey Tracker</h1>
      <p className="text-slate-500 mt-1">{appointment.test?.name}</p>

      {cancelled ? (
        <div className="mt-8 bg-red-50 text-red-700 rounded-2xl p-6 text-center font-medium">
          This booking was cancelled.
        </div>
      ) : (
        <div className="mt-10 bg-white rounded-2xl border border-slate-200 p-8">
          <div className="relative">
            {journey.map((step, idx) => (
              <div key={step.key} className="flex gap-4 pb-8 last:pb-0 relative">
                {idx !== journey.length - 1 && (
                  <div
                    className={`absolute left-[15px] top-8 w-0.5 h-full ${
                      step.done ? 'bg-brand-500' : 'bg-slate-200'
                    }`}
                  />
                )}
                <div
                  className={`w-8 h-8 rounded-full grid place-items-center text-xs font-bold shrink-0 z-10 ${
                    step.done
                      ? 'bg-brand-500 text-white'
                      : step.current
                      ? 'bg-brand-100 text-brand-600 border-2 border-brand-500'
                      : 'bg-slate-100 text-slate-400'
                  }`}
                >
                  {step.done ? '✓' : idx + 1}
                </div>
                <div>
                  <p className={`font-medium ${step.done || step.current ? 'text-slate-900' : 'text-slate-400'}`}>
                    {step.label}
                  </p>
                  {step.current && <p className="text-xs text-brand-600 mt-0.5">Current status</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-8 grid md:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900">Booking Details</h3>
          <dl className="mt-3 text-sm space-y-1 text-slate-600">
            <div className="flex justify-between"><dt>Date</dt><dd>{new Date(appointment.scheduledDate).toLocaleDateString()}</dd></div>
            <div className="flex justify-between"><dt>Slot</dt><dd>{appointment.scheduledSlot}</dd></div>
            <div className="flex justify-between"><dt>Type</dt><dd>{appointment.bookingType.replace('_', ' ')}</dd></div>
            <div className="flex justify-between"><dt>Status</dt><dd className="capitalize">{appointment.status.replace('_', ' ')}</dd></div>
          </dl>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-900">Payment</h3>
          {payment ? (
            <dl className="mt-3 text-sm space-y-1 text-slate-600">
              <div className="flex justify-between"><dt>Amount</dt><dd>₹{payment.amount}</dd></div>
              <div className="flex justify-between"><dt>Method</dt><dd className="capitalize">{payment.method}</dd></div>
              <div className="flex justify-between"><dt>Status</dt><dd className="capitalize">{payment.status}</dd></div>
              <div className="flex justify-between"><dt>Txn ID</dt><dd className="text-xs">{payment.transactionId}</dd></div>
            </dl>
          ) : (
            <p className="mt-3 text-sm text-slate-400">No payment made yet.</p>
          )}
        </div>
      </div>

      {report && (
        <div className="mt-4 bg-emerald-50 border border-emerald-200 rounded-2xl p-5 flex items-center justify-between">
          <div>
            <p className="font-semibold text-emerald-800">Your report is ready!</p>
            <p className="text-sm text-emerald-700">{report.fileName}</p>
          </div>
          <Link
            to="/reports"
            className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-semibold"
          >
            View Report
          </Link>
        </div>
      )}
    </div>
  );
}
