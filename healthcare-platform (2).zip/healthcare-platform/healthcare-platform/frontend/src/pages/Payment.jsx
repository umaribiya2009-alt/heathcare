import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/axios';

export default function Payment() {
  const { appointmentId } = useParams();
  const navigate = useNavigate();
  const [appointment, setAppointment] = useState(null);
  const [method, setMethod] = useState('card');
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api
      .get(`/appointments/${appointmentId}`)
      .then((res) => setAppointment(res.data.appointment))
      .catch((err) => setError(err.response?.data?.message || 'Failed to load booking'))
      .finally(() => setLoading(false));
  }, [appointmentId]);

  const handlePay = async () => {
    setProcessing(true);
    setError('');
    try {
      const initRes = await api.post('/payments', { appointmentId, method });
      const paymentId = initRes.data.payment._id;
      // Simulate gateway processing delay
      await new Promise((r) => setTimeout(r, 900));
      await api.post(`/payments/${paymentId}/confirm`);
      navigate(`/journey/${appointmentId}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Payment failed');
    } finally {
      setProcessing(false);
    }
  };

  if (loading) return <p className="text-center py-20 text-slate-400">Loading...</p>;
  if (!appointment) return <p className="text-center py-20 text-red-500">{error || 'Booking not found'}</p>;

  return (
    <div className="max-w-md mx-auto px-4 py-14">
      <div className="bg-white rounded-2xl border border-slate-200 p-8">
        <h1 className="text-xl font-bold text-slate-900">Complete Payment</h1>
        <p className="text-slate-500 text-sm mt-1">Secure checkout for your diagnostic test.</p>

        <div className="mt-6 bg-slate-50 rounded-xl p-4">
          <p className="font-medium text-slate-800">{appointment.test.name}</p>
          <p className="text-sm text-slate-500 mt-1">
            {new Date(appointment.scheduledDate).toLocaleDateString()} • {appointment.scheduledSlot}
          </p>
          <div className="flex justify-between mt-4 pt-4 border-t border-slate-200">
            <span className="text-slate-600">Amount to pay</span>
            <span className="font-bold text-lg text-slate-900">₹{appointment.test.price}</span>
          </div>
        </div>

        {error && <div className="mt-4 bg-red-50 text-red-700 text-sm px-4 py-2 rounded-lg">{error}</div>}

        <div className="mt-6">
          <label className="text-sm font-medium text-slate-700">Payment method</label>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {['card', 'upi', 'netbanking', 'wallet'].map((m) => (
              <button
                key={m}
                onClick={() => setMethod(m)}
                className={`py-2 rounded-lg border text-xs font-medium capitalize ${
                  method === m ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-slate-300 text-slate-600'
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handlePay}
          disabled={processing}
          className="mt-6 w-full py-2.5 rounded-lg bg-brand-500 text-white font-semibold hover:bg-brand-600 disabled:opacity-60"
        >
          {processing ? 'Processing payment...' : `Pay ₹${appointment.test.price}`}
        </button>
        <p className="mt-3 text-xs text-slate-400 text-center">
          This is a simulated payment for demo purposes. No real transaction occurs.
        </p>
      </div>
    </div>
  );
}
