import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';

const SLOTS = [
  '08:00 AM - 09:00 AM',
  '09:00 AM - 10:00 AM',
  '10:00 AM - 11:00 AM',
  '11:00 AM - 12:00 PM',
  '02:00 PM - 03:00 PM',
  '04:00 PM - 05:00 PM',
];

export default function BookTest() {
  const navigate = useNavigate();
  const [tests, setTests] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({
    bookingType: 'lab_visit',
    scheduledDate: '',
    scheduledSlot: '',
    address: '',
    notes: '',
  });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const load = async () => {
      const res = await api.get('/tests', { params: { search, category } });
      setTests(res.data.tests);
    };
    load();
  }, [search, category]);

  const categories = [...new Set(tests.map((t) => t.category))];

  const handleBook = async (e) => {
    e.preventDefault();
    setError('');
    if (form.bookingType === 'home_collection' && !form.address) {
      setError('Please provide an address for home sample collection.');
      return;
    }
    setSubmitting(true);
    try {
      const res = await api.post('/appointments', { testId: selected._id, ...form });
      navigate(`/payment/${res.data.appointment._id}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Booking failed');
    } finally {
      setSubmitting(false);
    }
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-900">Book a Diagnostic Test</h1>
      <p className="text-slate-500 mt-1">Choose a test, then schedule your appointment.</p>

      <div className="mt-6 flex flex-col md:flex-row gap-3">
        <input
          placeholder="Search tests (e.g. Blood, Thyroid, X-Ray)..."
          className="flex-1 rounded-lg border border-slate-300 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-brand-500"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="rounded-lg border border-slate-300 px-4 py-2.5"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      <div className="mt-6 grid md:grid-cols-2 gap-4">
        {tests.map((t) => (
          <div
            key={t._id}
            className={`rounded-2xl border p-5 cursor-pointer transition-colors ${
              selected?._id === t._id
                ? 'border-brand-500 bg-brand-50'
                : 'border-slate-200 bg-white hover:border-brand-300'
            }`}
            onClick={() => setSelected(t)}
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="font-semibold text-slate-900">{t.name}</p>
                <p className="text-xs text-slate-500 mt-0.5">{t.category}</p>
              </div>
              <p className="font-bold text-brand-600">₹{t.price}</p>
            </div>
            <div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-500">
              <span className="bg-slate-100 px-2 py-1 rounded-full">Sample: {t.sampleType}</span>
              <span className="bg-slate-100 px-2 py-1 rounded-full">
                Report in ~{t.reportTimeHours}h
              </span>
              {t.fastingRequired && (
                <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded-full">Fasting required</span>
              )}
              {t.homeCollectionAvailable && (
                <span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full">
                  Home collection available
                </span>
              )}
            </div>
          </div>
        ))}
        {tests.length === 0 && (
          <p className="text-slate-400 col-span-2 text-center py-10">No tests match your search.</p>
        )}
      </div>

      {selected && (
        <div className="mt-10 bg-white border border-slate-200 rounded-2xl p-6 max-w-xl">
          <h2 className="font-semibold text-slate-900">
            Schedule: <span className="text-brand-600">{selected.name}</span>
          </h2>

          {error && (
            <div className="mt-3 bg-red-50 text-red-700 text-sm px-4 py-2 rounded-lg">{error}</div>
          )}

          <form onSubmit={handleBook} className="mt-4 space-y-4">
            <div>
              <label className="text-sm font-medium text-slate-700">Booking type</label>
              <div className="mt-1 flex gap-3">
                <button
                  type="button"
                  onClick={() => setForm({ ...form, bookingType: 'lab_visit' })}
                  className={`flex-1 py-2 rounded-lg border text-sm font-medium ${
                    form.bookingType === 'lab_visit'
                      ? 'border-brand-500 bg-brand-50 text-brand-700'
                      : 'border-slate-300 text-slate-600'
                  }`}
                >
                  Visit Lab
                </button>
                <button
                  type="button"
                  disabled={!selected.homeCollectionAvailable}
                  onClick={() => setForm({ ...form, bookingType: 'home_collection' })}
                  className={`flex-1 py-2 rounded-lg border text-sm font-medium disabled:opacity-40 ${
                    form.bookingType === 'home_collection'
                      ? 'border-brand-500 bg-brand-50 text-brand-700'
                      : 'border-slate-300 text-slate-600'
                  }`}
                >
                  Home Collection
                </button>
              </div>
            </div>

            {form.bookingType === 'home_collection' && (
              <div>
                <label className="text-sm font-medium text-slate-700">Address</label>
                <textarea
                  required
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                  rows={2}
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-slate-700">Date</label>
                <input
                  type="date"
                  required
                  min={today}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                  value={form.scheduledDate}
                  onChange={(e) => setForm({ ...form, scheduledDate: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700">Time slot</label>
                <select
                  required
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                  value={form.scheduledSlot}
                  onChange={(e) => setForm({ ...form, scheduledSlot: e.target.value })}
                >
                  <option value="">Select slot</option>
                  {SLOTS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700">Notes (optional)</label>
              <textarea
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                rows={2}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
            </div>

            <button
              disabled={submitting}
              className="w-full py-2.5 rounded-lg bg-brand-500 text-white font-semibold hover:bg-brand-600 disabled:opacity-60"
            >
              {submitting ? 'Booking...' : `Confirm Booking — ₹${selected.price}`}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
