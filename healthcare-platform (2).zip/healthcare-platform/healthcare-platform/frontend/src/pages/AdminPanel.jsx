import React, { useEffect, useState } from 'react';
import api from '../api/axios';

const STATUS_FLOW = ['booked', 'confirmed', 'sample_collected', 'processing', 'report_ready', 'completed'];

const statusBadge = (status) => {
  const map = {
    booked: 'bg-slate-100 text-slate-700',
    confirmed: 'bg-blue-100 text-blue-700',
    sample_collected: 'bg-amber-100 text-amber-700',
    processing: 'bg-amber-100 text-amber-700',
    report_ready: 'bg-emerald-100 text-emerald-700',
    completed: 'bg-violet-100 text-violet-700',
    cancelled: 'bg-red-100 text-red-700',
  };
  return map[status] || 'bg-slate-100 text-slate-700';
};

export default function AdminPanel() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [uploadFor, setUploadFor] = useState(null);
  const [file, setFile] = useState(null);
  const [summary, setSummary] = useState('');
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    setLoading(true);
    const res = await api.get('/appointments', { params: filter ? { status: filter } : {} });
    setAppointments(res.data.appointments);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const updateStatus = async (id, status) => {
    await api.patch(`/appointments/${id}/status`, { status });
    load();
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('report', file);
      formData.append('appointmentId', uploadFor);
      formData.append('summary', summary);
      await api.post('/reports', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setUploadFor(null);
      setFile(null);
      setSummary('');
      load();
    } catch (err) {
      alert(err.response?.data?.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-900">Admin / Lab Panel</h1>
      <p className="text-slate-500 mt-1">Manage bookings, update status, and upload reports.</p>

      <div className="mt-5 flex gap-2 flex-wrap">
        {['', ...STATUS_FLOW, 'cancelled'].map((s) => (
          <button
            key={s || 'all'}
            onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium capitalize ${
              filter === s ? 'bg-brand-500 text-white' : 'bg-slate-100 text-slate-600'
            }`}
          >
            {s ? s.replace('_', ' ') : 'All'}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="mt-8 text-slate-400">Loading...</p>
      ) : (
        <div className="mt-6 space-y-3">
          {appointments.map((a) => (
            <div key={a._id} className="bg-white rounded-2xl border border-slate-200 p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-semibold text-slate-900">{a.test?.name}</p>
                  <p className="text-sm text-slate-500 mt-1">
                    Patient: {a.patient?.name} ({a.patient?.email}) •{' '}
                    {new Date(a.scheduledDate).toLocaleDateString()} • {a.scheduledSlot}
                  </p>
                  {a.bookingType === 'home_collection' && (
                    <p className="text-xs text-slate-400 mt-1">Home collection: {a.address}</p>
                  )}
                </div>
                <span className={`text-xs font-semibold px-3 py-1 rounded-full ${statusBadge(a.status)}`}>
                  {a.status.replace('_', ' ')}
                </span>
              </div>

              {a.status !== 'cancelled' && (
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <span className="text-xs text-slate-500">Advance status:</span>
                  {STATUS_FLOW.map((s, idx) => {
                    const currentIdx = STATUS_FLOW.indexOf(a.status);
                    const disabled = idx <= currentIdx;
                    return (
                      <button
                        key={s}
                        disabled={disabled}
                        onClick={() => updateStatus(a._id, s)}
                        className={`text-xs px-2.5 py-1 rounded-full border capitalize ${
                          disabled
                            ? 'border-slate-200 text-slate-300 cursor-not-allowed'
                            : 'border-brand-300 text-brand-700 hover:bg-brand-50'
                        }`}
                      >
                        {s.replace('_', ' ')}
                      </button>
                    );
                  })}
                  {a.status === 'processing' && (
                    <button
                      onClick={() => setUploadFor(a._id)}
                      className="text-xs px-3 py-1 rounded-full bg-emerald-500 text-white font-medium"
                    >
                      Upload Report
                    </button>
                  )}
                </div>
              )}

              {uploadFor === a._id && (
                <form onSubmit={handleUpload} className="mt-4 p-4 bg-slate-50 rounded-xl space-y-3">
                  <input
                    type="file"
                    accept=".pdf,.png,.jpg,.jpeg"
                    onChange={(e) => setFile(e.target.files[0])}
                    className="text-sm"
                  />
                  <input
                    placeholder="Short summary (optional)"
                    value={summary}
                    onChange={(e) => setSummary(e.target.value)}
                    className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2"
                  />
                  <div className="flex gap-2">
                    <button
                      type="submit"
                      disabled={uploading}
                      className="px-4 py-1.5 rounded-lg bg-brand-500 text-white text-sm font-semibold disabled:opacity-60"
                    >
                      {uploading ? 'Uploading...' : 'Submit Report'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setUploadFor(null)}
                      className="px-4 py-1.5 rounded-lg bg-slate-200 text-slate-700 text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}
            </div>
          ))}
          {appointments.length === 0 && (
            <p className="text-slate-400 text-center py-16">No bookings found.</p>
          )}
        </div>
      )}
    </div>
  );
}
