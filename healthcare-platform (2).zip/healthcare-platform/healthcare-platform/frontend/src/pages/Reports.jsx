import React, { useEffect, useState } from 'react';
import api from '../api/axios';

const API_ORIGIN = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace('/api', '');

export default function Reports() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get('/reports/mine')
      .then((res) => setReports(res.data.reports))
      .finally(() => setLoading(false));
  }, []);

  const openReport = async (r) => {
    // mark as viewed via API, then open the file
    await api.get(`/reports/${r._id}`);
    window.open(`${API_ORIGIN}${r.fileUrl}`, '_blank');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-900">My Reports</h1>
      <p className="text-slate-500 mt-1">All your diagnostic reports, delivered online.</p>

      {loading ? (
        <p className="mt-8 text-slate-400">Loading...</p>
      ) : reports.length === 0 ? (
        <p className="mt-10 text-center text-slate-400">No reports available yet.</p>
      ) : (
        <div className="mt-6 space-y-3">
          {reports.map((r) => (
            <div key={r._id} className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center justify-between">
              <div>
                <p className="font-semibold text-slate-900">{r.appointment?.test?.name}</p>
                <p className="text-sm text-slate-500 mt-1">
                  Uploaded {new Date(r.createdAt).toLocaleDateString()}
                </p>
                {r.summary && <p className="text-sm text-slate-600 mt-1">{r.summary}</p>}
              </div>
              <button
                onClick={() => openReport(r)}
                className="px-4 py-2 rounded-lg bg-brand-500 text-white text-sm font-semibold hover:bg-brand-600"
              >
                View / Download
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
