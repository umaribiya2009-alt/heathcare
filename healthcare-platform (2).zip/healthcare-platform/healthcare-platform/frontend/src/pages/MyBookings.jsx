import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';

const statusBadge = (status) => {
  const map = {
    booked: 'bg-slate-100 text-slate-700',
    confirmed: 'bg-blue-100 text-blue-700',
    sample_collected: 'bg-amber-100 text-amber-700',
    processing: 'bg-amber-100 text-amber-700',
    report_ready: 'bg-emerald-100 text-emerald-700',
    completed: 'bg-violet-100 text-violet-700',
    cancelled: 'bg-red-100 text-red-700',
  };
  return map[status] || 'bg-slate-100 text-slate-700';
};

export default function MyBookings() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  const load = async () => {
    setLoading(true);
    const res = await api.get('/appointments/mine');
    setAppointments(res.data.appointments);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const cancelBooking = async (id) => {
    if (!confirm('Cancel this booking?')) return;
    await api.patch(`/appointments/${id}/cancel`);
    load();
  };

  const filtered = appointments.filter((a) => filter === 'all' || a.status === filter);

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-slate-900">My Bookings</h1>

      <div className="mt-5 flex gap-2 flex-wrap">
        {['all', 'booked', 'confirmed', 'processing', 'report_ready', 'completed', 'cancelled'].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium capitalize ${
              filter === s ? 'bg-brand-500 text-white' : 'bg-slate-100 text-slate-600'
            }`}
          >
            {s.replace('_', ' ')}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="mt-8 text-slate-400">Loading...</p>
      ) : (
        <div className="mt-6 space-y-3">
          {filtered.length === 0 && (
            <p className="text-slate-400 text-center py-16">No bookings in this category.</p>
          )}
          {filtered.map((a) => (
            <div key={a._id} className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="font-semibold text-slate-900">{a.test?.name}</p>
                <p className="text-sm text-slate-500 mt-1">
                  {new Date(a.scheduledDate).toLocaleDateString()} • {a.scheduledSlot} •{' '}
                  {a.bookingType === 'home_collection' ? 'Home Collection' : 'Lab Visit'}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className={`text-xs font-semibold px-3 py-1 rounded-full ${statusBadge(a.status)}`}>
                  {a.status.replace('_', ' ')}
                </span>
                <Link
                  to={`/journey/${a._id}`}
                  className="text-sm font-medium text-brand-600 hover:underline"
                >
                  Track journey
                </Link>
                {['booked'].includes(a.status) && (
                  <button
                    onClick={() => cancelBooking(a._id)}
                    className="text-sm font-medium text-red-500 hover:underline"
                  >
                    Cancel
                  </button>
                )}
                {a.status === 'booked' && (
                  <Link
                    to={`/payment/${a._id}`}
                    className="text-sm font-medium px-3 py-1.5 rounded-lg bg-amber-500 text-white"
                  >
                    Pay now
                  </Link>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
