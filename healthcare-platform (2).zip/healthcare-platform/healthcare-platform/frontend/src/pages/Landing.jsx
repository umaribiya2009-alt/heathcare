import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Landing() {
  const { user } = useAuth();

  const features = [
    { title: 'Book Diagnostic Tests', desc: 'Browse a full catalog of lab tests and imaging scans, then book in a few clicks.' },
    { title: 'Schedule Appointments', desc: 'Pick a date, time slot, and choose home sample collection or an in-lab visit.' },
    { title: 'Secure Online Payments', desc: 'Pay for your bookings instantly with a transparent, trackable payment record.' },
    { title: 'Digital Reports', desc: 'Get lab reports delivered securely online as soon as they are ready.' },
    { title: 'Track Your Journey', desc: 'Follow every step — from booking to sample collection to report delivery.' },
  ];

  return (
    <div>
      <section className="max-w-6xl mx-auto px-4 pt-16 pb-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 leading-tight">
            Your health journey,
            <span className="text-brand-600"> simplified.</span>
          </h1>
          <p className="mt-4 text-slate-600 text-lg">
            Book diagnostic tests, schedule appointments, pay securely, and receive your reports
            online — all in one place.
          </p>
          <div className="mt-8 flex gap-4">
            <Link
              to={user ? '/book-test' : '/register'}
              className="px-6 py-3 rounded-xl bg-brand-500 text-white font-semibold hover:bg-brand-600"
            >
              {user ? 'Book a Test' : 'Get Started'}
            </Link>
            <Link
              to={user ? '/dashboard' : '/login'}
              className="px-6 py-3 rounded-xl border border-slate-300 font-semibold text-slate-700 hover:bg-slate-50"
            >
              {user ? 'Go to Dashboard' : 'Login'}
            </Link>
          </div>
        </div>
        <div className="rounded-3xl bg-gradient-to-br from-brand-500 to-brand-700 p-10 text-white shadow-xl">
          <p className="text-sm uppercase tracking-wide text-brand-100">Live Status</p>
          <h3 className="text-2xl font-bold mt-2">Track your test in real time</h3>
          <div className="mt-6 space-y-3 text-sm">
            {['Booked', 'Payment Confirmed', 'Sample Collected', 'Lab Processing', 'Report Ready'].map(
              (s, i) => (
                <div key={s} className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-white/20 grid place-items-center text-xs">
                    {i + 1}
                  </span>
                  <span>{s}</span>
                </div>
              )
            )}
          </div>
        </div>
      </section>

      <section className="bg-white border-t border-slate-100 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-slate-900 text-center">Everything you need</h2>
          <div className="mt-10 grid md:grid-cols-3 gap-6">
            {features.map((f) => (
              <div key={f.title} className="p-6 rounded-2xl border border-slate-200 hover:shadow-md transition-shadow">
                <h3 className="font-semibold text-slate-900">{f.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
