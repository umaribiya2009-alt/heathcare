import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-10">
      <div className="max-w-6xl mx-auto px-4 flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2 font-bold text-brand-700 text-lg">
          <span className="inline-block w-8 h-8 rounded-lg bg-brand-500 text-white grid place-items-center">+</span>
          MediBook
        </Link>

        {user ? (
          <div className="flex items-center gap-5 text-sm font-medium text-slate-600">
            <Link to="/dashboard" className="hover:text-brand-600">Dashboard</Link>
            <Link to="/book-test" className="hover:text-brand-600">Book a Test</Link>
            <Link to="/my-bookings" className="hover:text-brand-600">My Bookings</Link>
            <Link to="/reports" className="hover:text-brand-600">Reports</Link>
            {(user.role === 'admin' || user.role === 'lab_staff') && (
              <Link to="/admin" className="hover:text-brand-600">Admin Panel</Link>
            )}
            <span className="text-slate-400">|</span>
            <span className="text-slate-800">{user.name}</span>
            <button
              onClick={handleLogout}
              className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700"
            >
              Logout
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm font-medium text-slate-600 hover:text-brand-600">
              Login
            </Link>
            <Link
              to="/register"
              className="text-sm font-medium px-4 py-2 rounded-lg bg-brand-500 text-white hover:bg-brand-600"
            >
              Sign up
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}
