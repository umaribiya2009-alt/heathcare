/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef6ff',
          100: '#d9ebff',
          500: '#2f7bf6',
          600: '#1d63d6',
          700: '#164ea8',
        },
      },
    },
  },
  plugins: [],
};
