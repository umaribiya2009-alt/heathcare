# MediBook — Digital Healthcare Platform

A full-stack MERN application for booking diagnostic tests, scheduling appointments,
paying online, and tracking a patient's healthcare journey from booking to report delivery.

**Stack:** React.js (Vite + Tailwind) · Node.js · Express · MongoDB (Mongoose) · JWT Auth

---

## 1. Features

- **Auth** — patient registration/login with JWT; roles: `patient`, `admin`, `lab_staff`
- **Diagnostic test catalog** — searchable/filterable, seeded with 10 sample tests
- **Booking & scheduling** — choose lab visit or home sample collection, date + time slot
- **Payments** — mock payment gateway flow (swap in Razorpay/Stripe later without changing the frontend contract)
- **Reports** — lab staff/admin upload PDF/image reports; patients view/download them online
- **Journey tracking** — a visual step tracker (Booked → Payment Confirmed → Sample Collected →
  Lab Processing → Report Ready → Report Delivered) plus a dashboard with booking counts
- **Admin/Lab panel** — view all bookings, advance status, upload reports

## 2. Project structure

```
healthcare-platform/
├── backend/            Express + MongoDB API
│   ├── config/db.js
│   ├── models/         User, Test, Appointment, Report, Payment
│   ├── controllers/
│   ├── routes/
│   ├── middleware/auth.js
│   ├── uploads/reports/    (uploaded report files, served at /uploads)
│   ├── seed.js          seeds sample tests + admin/lab_staff accounts
│   └── server.js
└── frontend/            React (Vite) SPA
    └── src/
        ├── pages/        Landing, Login, Register, Dashboard, BookTest,
        │                 MyBookings, Payment, Journey, Reports, AdminPanel
        ├── components/   Navbar, ProtectedRoute
        ├── context/      AuthContext
        └── api/axios.js  API client with JWT interceptor
```

## 3. Setup

### Prerequisites
- Node.js 18+
- A MongoDB instance (local `mongod`, or a free MongoDB Atlas cluster)

### Backend

```bash
cd backend
cp .env.example .env      # edit MONGO_URI / JWT_SECRET as needed
npm install
npm run seed               # populates sample tests + demo admin/lab accounts
npm run dev                 # starts API on http://localhost:5000
```

Demo accounts created by `npm run seed`:
- Admin: `admin@healthcare.com` / `Admin@123`
- Lab staff: `lab@healthcare.com` / `Lab@1234`

### Frontend

```bash
cd frontend
cp .env.example .env      # VITE_API_URL defaults to http://localhost:5000/api
npm install
npm run dev                 # starts app on http://localhost:5173
```

Open `http://localhost:5173`, register a patient account, and walk through:
**Book a Test → Pay → Track Journey**. Log in as the seeded admin/lab account to
advance a booking's status and upload a report, then log back in as the patient to
view it under **Reports**.

## 4. API overview

| Method | Route                              | Access            | Purpose                          |
|--------|-------------------------------------|--------------------|-----------------------------------|
| POST   | /api/auth/register                 | public             | Patient sign-up                   |
| POST   | /api/auth/login                    | public             | Login                              |
| GET    | /api/auth/me                       | authenticated      | Current user profile              |
| GET    | /api/tests                         | public             | Browse/search test catalog        |
| POST   | /api/tests                         | admin              | Add a test                        |
| POST   | /api/appointments                  | patient            | Book a test appointment           |
| GET    | /api/appointments/mine             | patient            | My bookings                       |
| GET    | /api/appointments                  | admin/lab_staff    | All bookings                      |
| PATCH  | /api/appointments/:id/status       | admin/lab_staff    | Advance booking status            |
| PATCH  | /api/appointments/:id/cancel       | patient            | Cancel a booking                  |
| POST   | /api/payments                      | patient            | Initiate payment                  |
| POST   | /api/payments/:id/confirm          | patient            | Confirm payment (mock gateway)    |
| POST   | /api/reports (multipart)           | admin/lab_staff    | Upload a report file              |
| GET    | /api/reports/mine                  | patient            | My reports                        |
| GET    | /api/journey/:appointmentId        | authenticated      | Consolidated journey/timeline view|
| GET    | /api/journey/summary               | patient            | Dashboard counts                  |

## 5. Notes for production hardening

- Replace the mock payment flow in `paymentController.js` with a real gateway
  (Razorpay/Stripe order + signature-verified webhook).
- Move uploaded report files to S3/Cloud Storage instead of local disk.
- Add rate limiting, helmet, and input validation (e.g. `zod`/`joi`) on the API.
- Add email/SMS notifications on status changes (booking confirmed, report ready).
- Add refresh tokens / shorter-lived access tokens for stronger auth security.
